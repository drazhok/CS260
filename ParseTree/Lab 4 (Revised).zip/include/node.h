#ifndef NODE_H
#define NODE_H


class node
{
    public:
        node(char value);

        node *left;
        node *right;
        char data;
};

#endif
