#include "node.h"

// Initializes the values
node::node(char value) {
    data = value;
    left = nullptr;
    right = nullptr;
}
